package Main;

import java.util.ArrayList;

public class Biblioteca {

	// Attributes

	ArrayList<Libro> libri = new ArrayList<>();

	// Metodo per aggiungere un libro -> controlla se il codice gia' esiste 
	protected void addLibro(Libro libro) {
		for (Libro libro2: libri) {
			if (libro2.codiceIdentificativo == libro.codiceIdentificativo) {
				System.out.println("Codice gia esistente");
				return;
			}
		}
		System.out.println("Libro aggiunto! ");
		libri.add(libro);
	}

	// Metodo per stampare libri disponibili
	public void stampaDisponibili() {
		if (libri.isEmpty()) {
			System.out.println("Non ci sono libri, considera aggiungerne uno");
			return;
		}
		
		for (Libro libro : libri) {
			if (libro.disponibilita) {
				System.out.println(libro.titolo + " - " + libro.autore + " Disponibile (" + libro.codiceIdentificativo + ")");
			}
		}
	}

	// Metodo per stampare libri prestati
	public void stampaPrestati() {
		if (libri.isEmpty()) {
			System.out.println("Non ci sono libri, considera aggiungerne uno");
			return;
		}
		
		for (Libro libro : libri) {
			if (!libro.disponibilita) {
				System.out.println(libro.titolo + " - " + libro.autore + " Prestato");
			}
		}
	}

	// Metodo per stampare i libri
	public void stampaLibri() {
		if (libri.isEmpty()) {
			System.out.println("Non ci sono libri, considera aggiungerne uno");
			return;
		}
		for (Libro libro : libri) {
			System.out.println(libro.titolo + " - " + libro.autore + " " + libro.codiceIdentificativo);
		}
	}
	
	// Metodo per resituire un libro -> controlla se il codiceIdentificatore esiste e se e' una copia
	protected void restituireLibro(int codiceIdentificatore) {
		for (Libro libro : libri) {
			if (codiceIdentificatore == libro.codiceIdentificativo) {
				if (!libro.disponibilita) {
					libro.disponibilita = true;
					System.out.println("Hai restituito il libro");
				} else {
					System.out.println("Il libro e' una copia");
				}
				return;
			}
		}
		System.out.println("Libro non trovato");
		
	}
	
	// Metodo per prestare un libro -> controlla se il codiceIdentificatore esiste e se e' disponibile
	protected void prestareLibro(int codiceIdentificatore) {
		for (Libro libro : libri) {
			if (codiceIdentificatore == libro.codiceIdentificativo) {
				if (libro.disponibilita) {
					System.out.println("Hai preso un libro");
					libro.disponibilita = false;
				} else {
					System.out.println("Libro gia' prestato");
				}
				return;
			}
		}
		System.out.println("Libro non trovato");
	}
	
	
}
