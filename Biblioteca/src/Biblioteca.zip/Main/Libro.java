package Main;

public class Libro {
	
	// Attributes
	String titolo;
	String autore;
	String categoria;
	int codiceIdentificativo;
	boolean disponibilita;
	
	// Constructors
	Libro (String titolo, String autore, String categoria, int codiceIdentificativo, boolean disponibilita) {
		this.titolo = titolo;
		this.autore = autore;
		this.categoria = categoria;
		this.codiceIdentificativo = codiceIdentificativo;
		this.disponibilita = disponibilita;
	}
	
}
